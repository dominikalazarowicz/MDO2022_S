# Szymon Kupka 
## Docker files, kontener jako definicja etapu

